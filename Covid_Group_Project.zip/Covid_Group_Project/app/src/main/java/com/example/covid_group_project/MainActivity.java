package com.example.covid_group_project;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity<question1> extends AppCompatActivity implements GestureDetector.OnGestureListener {

    //Vars
    public static int Masks;
    public static int Supplies;
    public static int Social;
    public static int Sanity;
    public static int Question;
    public static Random r;
    QuestionObject [] questionArray;

    //Swipe vars and initialization
    private  float x1, x2;
    //, y1, y2;
    private static int min_DISTANCE = 150;
    private GestureDetector gestureDetector;

    //View field vars
    private ImageView imgMask;
    private ImageView imgSupplies;
    private ImageView imgSocial;
    private ImageView imgSanity;
    private TextView textquestion;

    //Image address array
    int[] images={R.drawable.ic_signal_wifi_0_bar_black_24dp, R.drawable.ic_signal_wifi_1_bar_black_24dp,
    R.drawable.ic_signal_wifi_3_bar_black_24dp, R.drawable.ic_signal_wifi_4_bar_black_24dp};

    //question array
    ArrayList<String> questions;

    //int main() {...
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //default stuff
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializing question array
        questions = new ArrayList<>();

        //Connecting vars with xml
        imgMask=(ImageView)findViewById(R.id.imageViewMasks);
        imgSupplies=(ImageView)findViewById(R.id.imageViewSupplies);
        imgSocial=(ImageView)findViewById(R.id.imageViewSocial);
        imgSanity=(ImageView)findViewById(R.id.imageViewSanity);
        textquestion=(TextView)findViewById(R.id.TextViewQuestion);

        //initializing vars
        setVariables();
        setDefaults();

        //initializing swipe function
        this.gestureDetector = new GestureDetector(MainActivity.this, this);

        //click functions
        //ImageClickRight();
        //ImageClickLeft();

        //Random Question Selection
        questionRandomizer();

    }


    private void questionResult() {
        if (x2 > x1){
            Masks++;
            if (Masks > 3) Masks=3;
            Masks=Masks % images.length;
            imgMask.setImageResource(images[Masks]);
            Supplies--;
            if (Supplies < 0) Supplies=0;
            Supplies=Supplies % images.length;
            imgSupplies.setImageResource(images[Supplies]);
            Social++;
            Social++;
            if (Social > 3) Social=3;
            Social=Social % images.length;
            imgSocial.setImageResource(images[Social]);
            Sanity++;
            if (Sanity > 3) Sanity=3;
            Sanity=Sanity % images.length;
            imgSanity.setImageResource(images[Sanity]);
        } else {
            Masks--;
            if (Masks < 0) Masks=0;
            Masks=Masks % images.length;
            imgMask.setImageResource(images[Masks]);
            Supplies++;
            if (Supplies > 3) Supplies=3;
            Supplies=Supplies % images.length;
            imgSupplies.setImageResource(images[Supplies]);
            Social--;
            if (Social < 0) Social=0;
            Social=Social % images.length;
            imgMask.setImageResource(images[Social]);
            Sanity--;
            if (Sanity < 0) Sanity=0;
            Sanity=Sanity % images.length;
            imgSanity.setImageResource(images[Sanity]);
        }

    }

    private String questionRandomizer() {
        String questionString = "default";
        if (questions.size() <= 1) {
            Intent intent = new Intent(MainActivity.this,EndGameActivity.class);
            startActivity(intent);
        }

        r= new Random();

        //Input random question, remove from question array afterward
            Question = r.nextInt(questions.size());
            Log.d("test", "Random question gen " + Question);
            questionString = questions.get(Question);
            questions.remove(Question);

            return questionString;

    }

    private void WinLoseResult() {
        //this is the final calulation screen
    }

    private void setDefaults() {
        //Questions input
        questions.add("Make a trip to the grocery store?");
        questions.add("Stay home on weekend?");
        questions.add("Have a friend come over to hangout?");
        questions.add("Look for a new job online?");
        questions.add("Go get the mail?");
        questions.add("Meet with parents for brunch?");
        questions.add("Go to the gym?");
        questions.add("Get food to-go from a restaurant?");
        questions.add("A walk around the block?");
        questions.add("Go and get a cup of coffee?");
        questions.add("Do an at home workout?");
        questions.add("Go to a Job interview?");
        questions.add("Donate to the food shelter?");
        questions.add("Order Masks online?");
        questions.add("Go on a Tinder date?");
        questions.add("Become a hermit?");
        questions.add("Become a -Virus Hoax- person?");

        //sets var meters to max by default
        Masks = 3;
        Supplies = 3;
        Social = 3;
        Sanity = 2;
        imgMask.setImageResource(images[Masks]);
        imgSupplies.setImageResource(images[Supplies]);
        imgSocial.setImageResource(images[Social]);
        imgSanity.setImageResource(images[Sanity]);

        r= new Random();

        //Input random first question, remove from question array after
        Question=r.nextInt(questions.size())-1;
        textquestion.setText(questions.get(Question));
        questions.remove(Question);
        Question--;

    }

   /* public void ImageClickRight(){
        ImageView imgviewbm = (ImageView) findViewById(R.id.BackGroundRight);
        imgviewbm.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                        textquestion.setText(QuestionRandomizer());
                        Masks++;
                        if (Masks > 3) Masks=3;
                        Masks=Masks % images.length;
                        imgMask.setImageResource(images[Masks]);
                    }
                }
        );
    }
      public void ImageClickLeft(){
        ImageView imgviewbm = (ImageView) findViewById(R.id.BackGroundLeft);
        imgviewbm.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                        textquestion.setText(QuestionRandomizer());
                        Masks--;
                        if (Masks < 0) Masks=0;
                        Masks=Masks % images.length;
                        imgMask.setImageResource(images[Masks]);
                    }
                }
        );
    }*/

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            gestureDetector.onTouchEvent(event);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    Log.d("test","Action Down");
                    x1 = event.getX();
                    //y1 = event.getY();
                    break;

                case MotionEvent.ACTION_UP:
                    x2 = event.getX();
                    //y2 = event.getY();
                    float valueX = x2 - x1;
                    //float valueY = y2 - y1;

                    if (Math.abs(valueX) > min_DISTANCE) {

                        if (x2 > x1) {
                            //right is swiped
                            Log.d("test","Right Swipe Distance = "+valueX);
                                            textquestion.setText(questionRandomizer());
                                            questionResult();
                                            return false;
                        } else {
                            //left is swiped
                            Log.d("test","Left Swipe Distance = "+valueX);
                                            textquestion.setText(questionRandomizer());
                                            questionResult();
                                            return false;
                        }

                    }
                    break;
            }
            return super.onTouchEvent(event);
        }

    private void setQuestion(int Index) {


    }

    private void setVariables() {
        //Objects are created
        QuestionObject Q01 = new QuestionObject("Make a trip to the grocery store.","This is the answer 1",R.drawable.ic_launcher_background,-1,2,-2,1,0,-2,1,-1);
        QuestionObject Q02 = new QuestionObject("Stay home on weekend","This is the answer 2",R.drawable.ic_launcher_background,0,-2,1,-1,-1,+2,-1,1);
        QuestionObject Q03 = new QuestionObject("Have a friend come over to hangout","This is the answer 3",R.drawable.ic_launcher_background,0,-2,-1,1,0,0,1,-1);
        QuestionObject Q04 = new QuestionObject("Look for a new job online","This is the answer 4",R.drawable.ic_launcher_background,0,-1,1,1,0,-1,1,-1);
        QuestionObject Q05 = new QuestionObject("Go get the mail.","This is the answer 5",R.drawable.ic_launcher_background,-1,0,-1,1,0,0,1,-1);
        QuestionObject Q06 = new QuestionObject("Go to the gym","This is the answer 6",R.drawable.ic_launcher_background,-1,-1,-1,2,0,-1,1,-1);
        QuestionObject Q07 = new QuestionObject("Get food to-go from a restaurant","This is the answer 7",R.drawable.ic_launcher_background,-1,1,-1,1,0,-1,1,-1);
        QuestionObject Q08 = new QuestionObject("A walk around the block.","This is the answer 8",R.drawable.ic_launcher_background,-1,0,-1,1,0,0,1,-1);
        QuestionObject Q09 = new QuestionObject("Go and get a cup of coffee","This is the answer 9",R.drawable.ic_launcher_background,-1,1,-1,1,0,0,1,-1);
        QuestionObject Q10 = new QuestionObject("Do an at home workout","This is the answer 10",R.drawable.ic_launcher_background,0,-1,1,1,0,-1,1,-1);
        QuestionObject Q11 = new QuestionObject("Go to a Job interview","This is the answer 11",R.drawable.ic_launcher_background,-1,0,-1,1,0,0,1,-1);
        QuestionObject Q12 = new QuestionObject("Donate to the food shelter","This is the answer 12",R.drawable.ic_launcher_background,-1,-2,-1,+2,0,0,0,-1);
        QuestionObject Q13 = new QuestionObject("Order Masks online","This is the answer 13",R.drawable.ic_launcher_background,3,-1,0,1,0,0,0,-1);
        QuestionObject Q14 = new QuestionObject("Go on a Tinder date","This is the answer 14",R.drawable.ic_launcher_background,-1,2,-1,2,0,-1,1,-2);
        QuestionObject Q15 = new QuestionObject("Become a hermit","This is the answer 15",R.drawable.ic_launcher_background,2,-2,2,-1,0,-1,0,0);
        QuestionObject Q16 = new QuestionObject("Become a “Virus Hoax” person","This is the answer 16",R.drawable.ic_launcher_background,-2,+2,-2,-2,1,-1,1,1);

        //Object array is created
        questionArray = new QuestionObject[]{
                Q01, Q02, Q03, Q04, Q05, Q06, Q07, Q08, Q09, Q10, Q11, Q12, Q13, Q14, Q15, Q16
        };


    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }
}
package com.example.covid_group_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SplashScreenActivity extends AppCompatActivity {

    private Button playButton;
    private Button tutorialButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);


        playButtonPress();
        tutorialButtonPress();
    }

    private void tutorialButtonPress() {
        tutorialButton = (Button) findViewById(R.id.tutorialButton);
        tutorialButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(SplashScreenActivity.this,TutorialActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }

    private void playButtonPress() {
        playButton = (Button) findViewById(R.id.playButton);
        playButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(SplashScreenActivity.this,MainActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }
}

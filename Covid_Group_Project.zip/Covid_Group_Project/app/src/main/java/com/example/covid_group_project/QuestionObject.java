package com.example.covid_group_project;

import java.util.ArrayList;

public class QuestionObject {

    public String mQuestion;
    public String mAnswer;

    public int mImage;
    public int yMasks, nMasks;
    public int ySupplies, nSupplies;
    public int ySocial, nSocial;
    public int ySanity, nSanity;

    public QuestionObject(String mQuestion, String mAnswer, int mImage, int yMasks, int ySupplies, int ySocial, int ySanity, int nMasks, int nSupplies, int nSocial, int nSanity) {
        this.mQuestion=mQuestion;
        this.mAnswer=mAnswer;
        this.mImage=mImage;
        this.yMasks=yMasks;
        this.nMasks=nMasks;
        this.ySupplies=ySupplies;
        this.nSupplies=nSupplies;
        this.ySocial=ySocial;
        this.nSocial=nSocial;
        this.ySanity=ySanity;
        this.nSanity=nSanity;
    }
    public String getQuestion(){
        return mQuestion;
    }
    public String getAnswer(){
        return mAnswer;
    }
    public int getImage(){
        return mImage;
    }
    public int getyMasks(){
        return yMasks;
    }
    public int getnMasks(){ return nMasks; }
    public int getySupplies(){ return ySupplies; }
    public int getnSupplies(){ return nSupplies; }
    public int getySocial(){
        return ySocial;
    }
    public int getnSocial(){
        return nSocial;
    }
    public int getySanity(){
        return ySanity;
    }
    public int getnSanity(){ return nSanity; }
}

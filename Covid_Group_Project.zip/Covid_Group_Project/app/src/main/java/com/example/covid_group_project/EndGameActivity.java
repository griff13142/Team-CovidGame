package com.example.covid_group_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class EndGameActivity extends AppCompatActivity {
    private TextView endGame;
    private Button restartButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_game);

        endGame = (TextView) findViewById(R.id.editTextEndGame);
        restartButton = (Button) findViewById(R.id.restartButton);


        tutorialButtonPress();

    }

    private void tutorialButtonPress() {
        restartButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(EndGameActivity.this,SplashScreenActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }
}

